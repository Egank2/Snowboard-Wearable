//
//  SnoWinApp.swift
//  SnoWin
//
//  Created by Aakash Mukherjee on 31/3/25.
//

import SwiftUI

@main
struct SnoWinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
