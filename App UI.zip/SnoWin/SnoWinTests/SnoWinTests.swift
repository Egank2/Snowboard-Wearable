//
//  SnoWinTests.swift
//  SnoWinTests
//
//  Created by Aakash Mukherjee on 31/3/25.
//

import Testing
@testable import SnoWin

struct SnoWinTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
